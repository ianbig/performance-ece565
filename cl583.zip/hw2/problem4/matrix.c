#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>
#include <stdint.h>

# define N 1024
int matrixA[N][N] = {{0}};
int matrixB[N][N] = {{0}};
int matrixC[N][N] = {{0}};


void init_matrix(int matrix[][N], size_t size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            matrix[i][j] = rand() % 100;
        }
    }
}


double calc_time(struct timespec start, struct timespec end) {
  double start_sec = (double)start.tv_sec*1000000000.0 + (double)start.tv_nsec;
  double end_sec = (double)end.tv_sec*1000000000.0 + (double)end.tv_nsec;
  if (end_sec < start_sec) {
    return 0;
  } else {
    return end_sec - start_sec;
  }
}

void check_matrix(int validate[][N], int correct[][N], size_t size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            assert(validate[i][j] == correct[i][j]);
        }
    }
}

void pattern_1() {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int sum = 0;
            for (int k = 0; k < N; k++) {
               sum += matrixA[i][k] * matrixB[k][j];
            }
            matrixC[i][j] = sum;
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = calc_time(start, end);
    fprintf(stderr, "Time: %f\n", time);
}

void pattern_2() {
    int tmp = 0;
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
     for (int j = 0; j < N; j++) {
        for (int k = 0; k < N; k++) {
            tmp = matrixB[k][j];
            for (int i = 0; i < N; i++) {
                matrixC[i][j] += matrixA[i][k] * tmp;
            }
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = calc_time(start, end);
    fprintf(stderr, "Time: %f\n", time);
}

void pattern_3() {
    int i, j, k;
    int tmp = 0;
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (int i = 0; i < N; i++) {
        for (int k = 0; k < N; k++) {
            int tmp = matrixA[i][k];
            for (int j = 0; j < N; j++) {
                matrixC[i][j] += matrixB[k][j] * tmp;
            }
        }
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = calc_time(start, end);
    fprintf(stderr, "Time: %f\n", time);
}

void loop_tiling() {
    int i, j, k, ii, jj; 
    double sum;
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (i = 0; i < N; i += 32) { 
        for (j = 0; j < N; j += 32 ) { 
            for (ii = i; ii < (i+32); ii++){
                for (jj = j; jj < (j+32); jj++) {
                    sum = 0; 
                    for (k = 0; k < N; k++) {
                        sum += matrixA[ii][k] *  matrixB[k][jj]; 
                    }                
                matrixC[ii][jj] = sum;
                }
            }       
        }    
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = calc_time(start, end);
    fprintf(stderr, "Time: %f\n", time);
}


int main(int argc, char ** argv) {
    init_matrix(matrixA, N);
    init_matrix(matrixB, N);
    // calculate correct answer
    int i, j, k;
    int sum = 0;
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            sum = 0;
            for (k = 0; k < N; k++) {
               sum += matrixA[i][k] * matrixB[k][j];
            }
            matrixC[i][j] = sum;
        }
    }

    pattern_1();
    pattern_2();
    pattern_3();
    loop_tiling();
}