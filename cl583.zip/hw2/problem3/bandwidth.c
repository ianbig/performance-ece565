#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#define DATASIZE 1024

double calc_time(struct timespec start, struct timespec end) {
  double start_sec = (double)start.tv_sec*1000000000.0 + (double)start.tv_nsec;
  double end_sec = (double)end.tv_sec*1000000000.0 + (double)end.tv_nsec;
  if (end_sec < start_sec) {
    return 0;
  } else {
    return end_sec - start_sec;
  }
}

void test_write_bandwidth() {
    char * arr = malloc(sizeof(*arr) * DATASIZE);
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (size_t i = 0; i < DATASIZE; i++) {
        arr[i] = 'a';
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = calc_time(start, end);
    fprintf(stderr, "Write Traffic\n");
    fprintf(stderr, "Time: %f\n", time);
    fprintf(stderr, "Latency: %f Bytes/ns\n\n", (DATASIZE) / time);
    free(arr);
}

void test_read_write_bandwidth() {
    char * arr = malloc(sizeof(*arr) * DATASIZE);
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (size_t i = 1; i < DATASIZE; i++) {
        arr[i] = arr[i - 1];
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = calc_time(start, end);
    fprintf(stderr, "1:1 Read-Write Traffic\n");
    fprintf(stderr, "Time: %f\n", time);
    fprintf(stderr, "Latency: %f Bytes/ns\n\n", (DATASIZE) / time);
    free(arr);
}

void test_read_read_write_bandwidth() {
    char * arr = malloc(sizeof(*arr) * DATASIZE);
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (size_t i = 2; i < DATASIZE; i++) {
        arr[i] = arr[i - 1] + arr[i - 2];
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    double time = calc_time(start, end);
    fprintf(stderr, "2:1 Read-Write Traffic\n");
    fprintf(stderr, "Time: %f\n", time);
    fprintf(stderr, "Latency: %f Bytes/ns\n\n", (DATASIZE) / time);
    free(arr);
}

int main(int argc, char ** argv) {
    test_write_bandwidth();
    test_read_write_bandwidth();
    test_read_read_write_bandwidth();
}